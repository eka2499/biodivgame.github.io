---
---

I'm **Chris Turner**, a Software Engineer.

I love all things computer science and maths.

Have a look at some of my working [projects].

For more check out my academic & professional [resume].

Contact me at [@username] or by [email].



[projects]: /projects
[resume]: https://demo.nurlan.co/hugo-vitae/
[@username]: https://twitter.com/username
[email]: mailto:email@example.com
