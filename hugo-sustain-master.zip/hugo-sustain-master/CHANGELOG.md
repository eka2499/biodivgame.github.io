# Changelog

### Version 1.1

- Treat `avatar` param as link
- Update Bootstrap version to v5
- Use built-in syntax highlighting, instead of `highlight.js`
- Update minimum required Hugo
- Remove jQuery
- Miscellaneous improvements, fixes and accessibility enhancements

### Version 1.0.1

- Added proper "Projects" page rendering
- Miscellaneous improvements, fixes and accessibility enhancements

### Version 1.0

- Initial release
